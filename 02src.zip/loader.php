<?php

require_once('Runner.php');
require_once('BaseRuckSackProblem.php');
require_once('RuckSackProblemBrute.php');
require_once('RuckSackProblemRatio.php');
require_once('RuckSackProblemBB.php');
require_once('RuckSackProblemDynamic.php');
require_once('RuckSackProblemFPTAS.php');
