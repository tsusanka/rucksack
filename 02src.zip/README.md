Rucksack problem MI-PAA

## Run

./main.php
