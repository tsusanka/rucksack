echo "doing 4"; time ./main.php data/input/knap_4.inst.dat > 4;
echo "doing 10"; time ./main.php data/input/knap_10.inst.dat > 10;
echo "doing 15"; time ./main.php data/input/knap_15.inst.dat > 15;
echo "doing 20"; time ./main.php data/input/knap_20.inst.dat > 20;
echo "doing 22"; time ./main.php data/input/knap_22.inst.dat > 22;
echo "doing 25"; time ./main.php data/input/knap_25.inst.dat > 25;

