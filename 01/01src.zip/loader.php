<?php

require_once('Runner.php');
require_once('BaseRuckSackProblem.php');
require_once('RuckSackProblemBrute.php');
require_once('RuckSackProblemRatio.php');
